fn main() {
  pritnln!("Hello world");
}
